package ced.cedclient.utils

import com.google.gson.*
import com.google.gson.annotations.JsonAdapter
import java.awt.Color.HSBtoRGB
import java.awt.Color.RGBtoHSB
import java.lang.reflect.Type

/**
 * HSB-backed color, ported from Odin. Stores hue/saturation/brightness/alpha
 * and lazily recomputes the packed [rgba] int only when one of those changes
 * — this is what makes brighter()/darker() (which nudge brightness) cheap
 * and keeps hue stable through repeated adjustments, unlike mutating a raw
 * RGB int directly.
 */
@JsonAdapter(Color.ColorSerializer::class)
class Color(hue: Float, saturation: Float, brightness: Float, alpha: Float = 1f) {
    constructor(hsb: FloatArray, alpha: Float = 1f) : this(hsb[0], hsb[1], hsb[2], alpha)
    constructor(r: Int, g: Int, b: Int, alpha: Float = 1f) : this(RGBtoHSB(r, g, b, FloatArray(size = 3)), alpha)
    constructor(rgba: Int) : this(rgba.red, rgba.green, rgba.blue, alpha = rgba.alpha / 255f)
    constructor(rgba: Int, alpha: Float) : this(rgba.red, rgba.green, rgba.blue, alpha)
    constructor(hex: String) : this(
        hex.take(2).toInt(16),
        hex.substring(2, 4).toInt(16),
        hex.substring(4, 6).toInt(16),
        hex.substring(6, 8).toInt(16) / 255f
    )

    var hue = hue
        set(value) {
            field = value
            needsUpdate = true
        }

    var saturation = saturation
        set(value) {
            field = value
            needsUpdate = true
        }

    var brightness = brightness
        set(value) {
            field = value
            needsUpdate = true
        }

    var alphaFloat = alpha
        set(value) {
            field = value
            needsUpdate = true
        }

    /**
     * Used to tell [rgba] to recompute when the HSBA values are changed.
     */
    @Transient
    private var needsUpdate = true

    /**
     * Packed RGBA value. Recomputed from HSBA on first read after a change.
     */
    var rgba: Int = 0
        get() {
            if (needsUpdate) {
                field =
                    (HSBtoRGB(hue, saturation, brightness) and 0x00FFFFFF) or ((this.alphaFloat * 255).toInt() shl 24)
                needsUpdate = false
            }
            return field
        }

    inline val red get() = rgba.red
    inline val green get() = rgba.green
    inline val blue get() = rgba.blue
    inline val alpha get() = rgba.alpha

    inline val redFloat get() = red / 255f
    inline val greenFloat get() = green / 255f
    inline val blueFloat get() = blue / 255f

    @OptIn(ExperimentalStdlibApi::class)
    fun hex(includeAlpha: Boolean = true): String {
        val hexString = rgba.toHexString(HexFormat.UpperCase)
        return if (includeAlpha) hexString.substring(2) + hexString.take(2)
        else hexString.substring(2)
    }

    /**
     * Whether this color isn't visible at all — use to skip a draw call
     * outright rather than rendering a fully transparent shape.
     */
    inline val isTransparent: Boolean
        get() = this.alpha == 0

    override fun toString(): String = "Color(red=$red,green=$green,blue=$blue,alpha=$alpha)"

    override fun hashCode(): Int {
        var result = hue.toInt()
        result = 31 * result + saturation.toInt()
        result = 31 * result + brightness.toInt()
        result = 31 * result + this.alphaFloat.toInt()
        return result
    }

    override fun equals(other: Any?): Boolean {
        if (other === this) return true
        if (other is Color) {
            return rgba == other.rgba
        }
        return false
    }

    fun copy(): Color = Color(this.rgba)

    private class ColorSerializer : JsonDeserializer<Color>, JsonSerializer<Color> {
        override fun deserialize(json: JsonElement, type: Type, context: JsonDeserializationContext?): Color {
            return Color(json.asString.drop(1))
        }

        override fun serialize(color: Color, type: Type, context: JsonSerializationContext?): JsonElement {
            return JsonPrimitive("#${color.hex()}")
        }
    }

    companion object {

        fun Color.brighter(factor: Float = 1.3f): Color {
            return Color(
                hue, saturation, (brightness * factor.coerceAtLeast(1f)).coerceAtMost(1f),
                this.alphaFloat
            )
        }

        fun Color.darker(factor: Float = 0.7f): Color {
            return Color(hue, saturation, brightness * factor, this.alphaFloat)
        }

        fun Color.withAlpha(alpha: Float, newInstance: Boolean = true): Color {
            return if (newInstance) Color(red, green, blue, alpha)
            else {
                this.alphaFloat = alpha
                this
            }
        }

        fun Color.multiplyAlpha(factor: Float): Color {
            return Color(red, green, blue, (alphaFloat * factor).coerceIn(0f, 1f))
        }

        fun Color.hsbMax(): Color {
            return Color(hue, 1f, 1f)
        }
    }
}

object Colors {

    @JvmField val MINECRAFT_DARK_BLUE = Color(0, 0, 170)
    @JvmField val MINECRAFT_DARK_GREEN = Color(0, 170, 0)
    @JvmField val MINECRAFT_DARK_AQUA = Color(0, 170, 170)
    @JvmField val MINECRAFT_DARK_RED = Color(170, 0, 0)
    @JvmField val MINECRAFT_DARK_PURPLE = Color(170, 0, 170)
    @JvmField val MINECRAFT_GOLD = Color(255, 170, 0)
    @JvmField val MINECRAFT_GRAY = Color(170, 170, 170)
    @JvmField val MINECRAFT_DARK_GRAY = Color(85, 85, 85)
    @JvmField val MINECRAFT_BLUE = Color(85, 85, 255)
    @JvmField val MINECRAFT_GREEN = Color(85, 255, 85)
    @JvmField val MINECRAFT_AQUA = Color(85, 255, 255)
    @JvmField val MINECRAFT_RED = Color(255, 85, 85)
    @JvmField val MINECRAFT_LIGHT_PURPLE = Color(255, 85, 255)
    @JvmField val MINECRAFT_YELLOW = Color(255, 255, 85)
    @JvmField val WHITE = Color(255, 255, 255)
    @JvmField val BLACK = Color(0, 0, 0)
    @JvmField val TRANSPARENT = Color(0, 0, 0, 0f)

    @JvmField val gray38 = Color(38, 38, 38)
    @JvmField val gray26 = Color(26, 26, 26)
}