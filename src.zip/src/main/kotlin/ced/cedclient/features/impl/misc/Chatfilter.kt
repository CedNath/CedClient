package ced.cedclient.features.impl.misc

import ced.cedclient.features.Category
import ced.cedclient.features.Module
import ced.cedclient.features.settings.ActionSetting
import ced.cedclient.features.settings.BooleanSetting
import ced.cedclient.ui.clickgui.ChatFilterPopup
import ced.cedclient.ui.clickgui.ClickGUI
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import net.minecraft.client.Minecraft
import java.io.File
import java.util.UUID

/**
 * One filterable chat line.
 *
 * Default (built-in) entries are always full regex, matched with
 * Regex.matches() against the whole line -- same semantics as
 * NoammAddons' uselessMessages.json, since those patterns rely on that
 * precision (^/$ anchors, .+ wildcards).
 *
 * Custom (user-added) entries default to `isRegex = false`: plain,
 * case-insensitive "does this line contain this text" matching, so adding
 * your own filter doesn't require knowing regex. Toggling "Regex" on in
 * the popup when adding one switches that entry to the same
 * Regex.matches() behavior as the defaults, for anyone who wants it.
 */
data class ChatFilterEntry(
    val id: String,
    val pattern: String,
    var enabled: Boolean,
    val custom: Boolean = false,
    val isRegex: Boolean = custom.not() // defaults never customize this; custom entries default to plain text
) {
    // Invalid regex (only reachable via a hand-typed custom entry in regex
    // mode) just never matches, rather than crashing the chat pipeline --
    // mirrors Noamm's `catch { Regex(str) }` guard on /chathider add.
    val regex: Regex? by lazy { if (isRegex) runCatching { Regex(pattern) }.getOrNull() else null }

    fun matches(line: String): Boolean =
        if (isRegex) regex?.matches(line) == true else line.contains(pattern, ignoreCase = true)
}

/**
 * Hides configured chat lines. Unlike NoammAddons' single on/off switch for
 * its whole bundled list, every default line here is individually
 * toggleable from ChatFilterPopup, and custom filters (plain text by
 * default, regex optional) can be added/removed the same way.
 *
 * The module's own enabled/disabled (the ClickGUI panel toggle) is the
 * master switch -- when off, shouldHide() always returns false regardless
 * of individual entry state.
 *
 * IMPORTANT: on Hypixel (and most heavily-modded servers), real player
 * messages -- guild chat, party chat, public/local chat -- are sent as the
 * SAME packet type as spam/notification lines (system chat), because these
 * servers don't use vanilla's signed player-chat system for their own
 * custom-formatted chat. So the mixin only hooking handleSystemChat does
 * NOT by itself protect real player messages the way it would on vanilla.
 * playerChatGuard below is the actual protection: any line that LOOKS like
 * a real chat message (has a channel prefix and/or a sender name followed
 * by a colon) is exempted from every filter, default or custom, before any
 * pattern is even checked.
 */
object ChatFilter : Module(
    "ChatFilter",
    Category.Misc,
    "Hides configured chat messages (spam, join/leave, dungeon noise, etc.)"
) {
    private val openFilterMenu = ActionSetting("Configure Filters") {
        val mc = Minecraft.getInstance()
        (mc.screen as? ClickGUI)?.openPopup(ChatFilterPopup())
    }

    // Collapses consecutive blank chat lines into one, same as Noamm's
    // lastMessageBlank behavior -- a lot of the patterns below leave behind
    // an empty line where the hidden message used to be.
    private val collapseBlankLines = BooleanSetting("Collapse Blank Lines", true)
    private var lastMessageBlank = false

    // Matches Hypixel's real-chat line shapes, e.g.:
    //   Guild > PlayerName: hey guys
    //   Guild > [MVP+] PlayerName [Staff]: hey guys
    //   Party > PlayerName: ready?
    //   PlayerName: hello                              (public/local chat)
    //   [MVP++] PlayerName: hello                       (public chat w/ rank)
    // Deliberately loose (rank tag is optional, name is 1-16 word chars per
    // Minecraft's own username rules) -- false positives here just mean an
    // occasional non-chat line slips through unfiltered, which is a far
    // safer failure mode than a real player's message getting eaten.
    private val playerChatGuard = Regex(
        """^(?:(?:Guild|Party|Co-op|Officer) > )?(?:\[[^\]]+] )*\w{1,16}(?: \[[^\]]+])*\s*:.*""",
        RegexOption.DOT_MATCHES_ALL
    )

    // Imported verbatim from NoammAddons' uselessMessages.json (26.1.2).
    // All default-enabled; toggle individual ones off in the popup.
    private val defaultPatterns: List<String> = listOf(
        """^Warping you to your SkyBlock island\.\.\.$""",
        """^Warping...$""",
        """Sending to server .+""",
        """Queuing... .+""",
        """Welcome to Hypixel SkyBlock!""",
        """Latest update: SkyBlock .+""",
        """^You are playing on profile: .+$""",
        """^Profile ID: .+$""",
        """Error initializing players: undefined Hidden""",
        """^ {2}Clicking sketchy links can result in your account$""",
        """^ {2}being stolen!$""",
        """^ {2}Link looks suspicious\? - Don't click it!$""",
        """Blacklisted modifications are a bannable offense!""",
        """\[WATCHDOG ANNOUNCEMENT]""",
        """^Watchdog has banned .+ players in the last 7 days.$""",
        """Staff have banned an additional .+""",
        """A .+ Key was picked up!?""",
        """RIGHT CLICK on .+ to open it\. This key can only be used to open 1 door!""",
        """.+ opened a .+ door!""",
        """You hear the sound of something opening...""",
        """You do not have the key for this door!""",
        """^A mystical force .+""",
        """You cannot use abilities in this room!""",
        """You cannot do that in this room!""",
        """^You don't have enough charges to break this block right now!$""",
        """There are blocks in the way!""",
        """This creature is immune to this kind of magic!""",
        """This lever has already been used.""",
        """This chest has already been searched!""",
        """You have already opened this dungeon chest!""",
        """Someone has already activated this lever!""",
        """That chest is locked!""",
        """This item's ability is temporarily disabled!""",
        """This item is on cooldown.+""",
        """This ability is on cooldown.+""",
        """Your Ultimate is currently on cooldown for .+ more seconds.""",
        """You do not have enough mana to do this!""",
        """You need at least .+ mana to activate this!""",
        """.+ is ready to use! Press DROP to activate it!""",
        """Throwing Axe is now available!""",
        """Guided Sheep is now available!""",
        """Your Berserk ULTIMATE Ragnarok is now available!""",
        """Used Ragnarok!""",
        """Used Throwing Axe!""",
        """.+ is now ready!""",
        """Your .+ stats are doubled because you are the only player using this class!""",
        """(Archer|Mage|Berserker|Tank|Healer) Milestone.+""",
        """^You earned .+ Event EXP from playing SkyBlock!$""",
        """You earned .+ GEXP from playing .+!""",
        """BONUS! Temporarily earn [0-9]+% more skill experience!""",
        """ESSENCE! .+ found .+ Essence!""",
        """.+ unlocked .+ Essence.+""",
        """ {4}.+ Essence x.+""",
        """.+ found a Wither Essence! Everyone gains an extra essence!""",
        """Goldor's TNT Trap hit you for [\d,.]+ true damage.""",
        """Necron's Nuclear Frenzy hit you for .+ damage.""",
        """Goldor's Greatsword hit you for .+ damage.""",
        """The Frozen Adventurer used Ice Spray on you!""",
        """The Lost Adventurer used Dragon's Breath on you!""",
        """A Crypt Wither Skull exploded, hitting you for .+ damage.""",
        """The .+ Trap hit you for .+ damage!""",
        """The Mage's Magma burnt you for .+ true damage.""",
        """.+ (?:struck|hit|exploded) .+ (?:for |you for ).+""",
        """Your .+ hit .+ for [\d,.]+ damage\.""",
        """Your .+ hit .+ (?:enemy|enemies) for .+ damage.""",
        """Your Spirit Pet hit .+ enemy for .+ damage.""",
        """.+ healed you for .+ health!""",
        """You were healed for .+ health by .+!""",
        """You were healed for .+ health by .+'s Healing Bow and gained \+.+ Strength for 10 seconds.""",
        """Your fairy healed yourself for .+ health!""",
        """Your fairy healed .+ for .+ health!""",
        """.+ fairy healed you for .+ health!""",
        """Your Spirit Pet healed .+ for .+ health!""",
        """Your tether with .+ healed you for .+ health.""",
        """BUFF! You were splashed by .+ with Healing VIII!""",
        """BUFF! You have gained Healing V!""",
        """You gained .+ HP worth of absorption for 3s from .+!""",
        """.+ granted you .+ strength for 20 seconds!""",
        """Your bone plating reduced the damage you took by .+!""",
        """.+ formed a tether with you!""",
        """.+ used .+ on you!""",
        """Mute silenced you!""",
        """.+ picked up your .+ Orb!""",
        """.+ You picked up a .+ Orb from .+ healing you for .+ and granting you \+.+% .+ for 10 seconds.""",
        """^Creeper Veil Activated!$""",
        """^Creeper Veil De-activated!$""",
        """Creeper Veil Activated!""",
        """Creeper Veil De-activated!""",
        """DUNGEON BUFF! .+""",
        """A Blessing of .+ was picked up!""",
        """.+ has obtained Blessing of .+!""",
        """ {5}(?:Also )?(?:grants|granted) you .+""",
        """.*Granted you.+""",
        """.+ has obtained Superboom TNT( x[0-9])?!""",
        """.+ has obtained Revive Stone!""",
        """.+ has obtained Premium Flesh!""",
        """.+ has obtained Beating Heart!""",
        """RARE DROP! Hunk of Blue Ice \(\+.+% Magic Find!\)""",
        """RARE DROP! Beating Heart .+""",
        """PUZZLE SOLVED!.+""",
        """PUZZLE SOLVED! .+ wasn't fooled by .+! Good job!""",
        """PUZZLE SOLVED! .+ tied Tic Tac Toe! Good job!""",
        """\[STATUE].+""",
        """You cannot move the silverfish in that direction!""",
        """You cannot hit the silverfish while it's moving!""",
        """It isn't your turn!""",
        """Don't move diagonally! Bad!""",
        """Oops! You stepped on the wrong block!""",
        """\[BOSS] .+""",
        """\[NPC] Hugo""",
        """.+ Mort: .+""",
        """\[NPC] Mort: Talk to me to change your class and ready up\.""",
        """.+ the Fairy: .+""",
        """^The Redstone Pigmen are unhappy with you stealing their ores! Look out!$""",
        """A shiver runs down your spine...""",
        """Giga Lightning.+""",
        """\[SKULL] .+""",
        """\[BOMB] Creeper:.+""",
        """\[Sacks] .+""",
        """You summoned your.+""",
        """Your Auto Recombobulator recombobulated""",
        """ Experience Team Bonus""",
        """Inventory full\? Don't forget to check out your Storage inside the SkyBlock Menu!""",
        """You cannot put this item in the Potion Bag!""",
        """You don't have any inventory space!""",
        """You have .+ unclaimed .+""",
        """Your active Potion Effects have been paused and stored. They will be restored when you leave Dungeons! You are not allowed to use existing Potion Effects while in Dungeons.""",
        """You are not allowed to use Potion Effects while in Dungeon, therefore all active effects have been paused and stored\. They will be restored when you leave Dungeon!""",
        """Whow! Slow down there!""",
        """Woah slow down, you're doing that too fast!""",
        """Command Failed: This command is on cooldown! Try again in about a second!""",
        """Please wait a few seconds between refreshing!""",
        """Please wait a bit before doing this!""",
        """This menu is disabled here!""",
        """This Terminal doesn't seem to be responsive at the moment.""",
        """You have 60 seconds to warp out! CLICK to warp now!""",
        """Only up to 2 rules may trigger at once!""",
        """Some of your autopet rules did not trigger.""",
        """.+ the lobby!.*""",
        """Hoppity's Hunt has begun! Help Hoppity find his Chocolate Rabbit Eggs across SkyBlock each day during the Spring!""",
        """ +You have [0-9]+ unclaimed event rewards!""",
        """ +Event rewards are deleted after 10 SkyBlock years!""",
        """\+[0-9]+ Kill Combo.*""",
        """Your Kill Combo has expired! You reached a [0-9]+ Kill Combo!""",
        """Your Auto Recombobulator recombobulated .+!"""
    )

    private val defaultEntries: List<ChatFilterEntry> =
        defaultPatterns.mapIndexed { index, pattern ->
            ChatFilterEntry("default_$index", pattern, enabled = true, custom = false, isRegex = true)
        }

    private val entries: MutableList<ChatFilterEntry> = mutableListOf()

    /** Snapshot for the popup to render -- default entries first, then custom, in that order. */
    fun currentEntries(): List<ChatFilterEntry> = entries.toList()

    fun setEnabled(id: String, value: Boolean) {
        entries.firstOrNull { it.id == id }?.enabled = value
        save()
    }

    /**
     * Adds a custom filter. Plain text by default (isRegex = false): matched
     * as a case-insensitive substring, so "outbid" hides any line containing
     * that word, no regex needed. Pass isRegex = true (the popup's "Regex"
     * toggle) for full Regex.matches() behavior instead, same as the
     * built-in defaults -- rejected silently if it doesn't compile.
     */
    fun addCustom(pattern: String, isRegex: Boolean = false) {
        val trimmed = pattern.trim()
        if (trimmed.isEmpty()) return
        if (entries.any { it.pattern == trimmed && it.isRegex == isRegex }) return
        val entry = ChatFilterEntry(UUID.randomUUID().toString(), trimmed, enabled = true, custom = true, isRegex = isRegex)
        if (isRegex && entry.regex == null) return // invalid regex syntax
        entries.add(entry)
        save()
    }

    fun removeCustom(id: String) {
        entries.removeAll { it.id == id && it.custom }
        save()
    }

    /** Called from the chat-receive mixin. True = drop the message before it reaches chat. */
    fun shouldHide(rawText: String): Boolean {
        if (!isEnabled) return false

        if (rawText.isBlank()) {
            val hide = collapseBlankLines.value && lastMessageBlank
            lastMessageBlank = true
            return hide
        }
        lastMessageBlank = false

        // Real player messages never get filtered, no matter what patterns
        // are enabled -- checked before any filter runs.
        if (playerChatGuard.matches(rawText)) return false

        return entries.any { it.enabled && it.matches(rawText) }
    }

    // -------------------------
    // Persistence -- own file, same pattern as EntityESP's name filters.
    // Only enabled-state (by id) + the custom list round-trip; default
    // pattern text itself always comes from defaultPatterns above, so
    // editing/adding a default pattern in code doesn't require a migration.
    // -------------------------
    private data class SavedState(val disabledDefaultIds: List<String>, val custom: List<ChatFilterEntry>)

    private val gson = Gson()
    private val filtersFile: File by lazy {
        File(Minecraft.getInstance().gameDirectory, "cedclient/chat_filters.json")
    }

    private fun save() {
        try {
            filtersFile.parentFile?.mkdirs()
            val disabledDefaults = entries.filter { !it.custom && !it.enabled }.map { it.id }
            val custom = entries.filter { it.custom }
            filtersFile.writeText(gson.toJson(SavedState(disabledDefaults, custom)))
        } catch (e: Exception) {
            println("[ChatFilter] Failed to save filters: ${e.message}")
        }
    }

    private fun load() {
        entries.clear()
        entries.addAll(defaultEntries.map { it.copy() })

        try {
            if (filtersFile.exists()) {
                val type = object : TypeToken<SavedState>() {}.type
                val loaded: SavedState? = gson.fromJson(filtersFile.readText(), type)
                if (loaded != null) {
                    for (id in loaded.disabledDefaultIds) {
                        entries.firstOrNull { it.id == id && !it.custom }?.enabled = false
                    }
                    entries.addAll(loaded.custom)
                }
            }
        } catch (e: Exception) {
            println("[ChatFilter] Failed to load filters: ${e.message}")
        }
    }

    init {
        load()
        addSettings(openFilterMenu, collapseBlankLines)
    }
}
