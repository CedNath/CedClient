package com.cedclient.feature.loot

/**
 * Accumulates item drops parsed out of suppressed reward chat spam (Kuudra "PAID CHEST REWARDS"
 * blocks, rare reward broadcasts, etc.) so they can be shown later as one consolidated list
 * instead of flooding chat line-by-line.
 *
 * Reset this the same way ItemCooldowns resets on world swap (compare ClientLevel references
 * in your existing ClientTickEvents listener) so counts don't bleed between Kuudra/Dungeon runs.
 */
object LootTracker {

    data class LootEntry(var count: Int = 0)

    private val entries = LinkedHashMap<String, LootEntry>()
    private val rareRewards = mutableListOf<String>()
    private val dungeonRewards = mutableListOf<String>() // TODO: populate once patterns confirmed

    @Volatile
    var chestsOpened: Int = 0
        private set

    fun reset() {
        entries.clear()
        rareRewards.clear()
        dungeonRewards.clear()
        chestsOpened = 0
    }

    fun recordChestOpened() {
        chestsOpened++
    }

    /**
     * @param rawLine an already-stripped-of-color item line, e.g. "Kuudra Teeth x2"
     *                or "Crimson Essence x500 (x2)"
     */
    fun recordDrop(rawLine: String) {
        val (name, qty) = parseItemLine(rawLine) ?: return
        entries.getOrPut(name) { LootEntry() }.count += qty
    }

    fun recordRareReward(playerName: String, itemName: String, chestType: String) {
        rareRewards += "$playerName found $itemName ($chestType Chest)"
    }

    // TODO: call this once dungeon reward chat patterns are confirmed against a real log
    fun recordDungeonReward(rawLine: String) {
        dungeonRewards += rawLine
    }

    // Matches "Name xN" and the stacked variant "Name xN (xM)"
    private val ITEM_QTY_REGEX = Regex("""^(.*?)\s*x(\d+)(?:\s*\(x(\d+)\))?$""")

    private fun parseItemLine(line: String): Pair<String, Int>? {
        val clean = line.trim()
        if (clean.isEmpty()) return null

        val match = ITEM_QTY_REGEX.find(clean)
        return if (match != null) {
            val name = match.groupValues[1].trim()
            val baseQty = match.groupValues[2].toIntOrNull() ?: 1
            val multiplier = match.groupValues[3].toIntOrNull() ?: 1
            name to (baseQty * multiplier)
        } else {
            clean to 1
        }
    }

    fun buildSummaryLines(): List<String> {
        if (entries.isEmpty() && rareRewards.isEmpty() && dungeonRewards.isEmpty()) {
            return listOf("No loot tracked yet.")
        }

        val lines = mutableListOf<String>()
        lines += "Loot summary ($chestsOpened chests opened):"
        entries.entries
            .sortedByDescending { it.value.count }
            .forEach { (name, entry) -> lines += "  ${entry.count}x $name" }

        if (rareRewards.isNotEmpty()) {
            lines += "Rare rewards:"
            rareRewards.forEach { lines += "  $it" }
        }

        if (dungeonRewards.isNotEmpty()) {
            lines += "Dungeon rewards:"
            dungeonRewards.forEach { lines += "  $it" }
        }

        return lines
    }
}