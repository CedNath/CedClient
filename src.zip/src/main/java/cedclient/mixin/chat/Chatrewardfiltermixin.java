package com.cedclient.mixin.chat;

import com.cedclient.feature.loot.LootTracker;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Suppresses the "PAID CHEST REWARDS" block, "RARE REWARD!" broadcasts, and the
 * "[IQ] Chest tracker: X/60" line from chat, forwarding parsed loot into LootTracker
 * instead of letting it flood the chat window.
 *
 * NOTE: this also cancels ANY blank system-chat line, since Hypixel uses blank lines purely
 * as spacers around these blocks and there's no reliable way to tell in advance whether a
 * given blank line is about to start a reward block. If you rely on blank chat lines
 * elsewhere for spacing, this will eat those too.
 */
@Mixin(ClientPacketListener.class)
public abstract class ChatRewardFilterMixin {

    private static final Pattern HEADER = Pattern.compile("^PAID CHEST REWARDS$");
    private static final Pattern RARE_REWARD =
            Pattern.compile("^RARE REWARD! (.+) found a (.+) in their (.+) Chest!$");
    private static final Pattern CHEST_TRACKER = Pattern.compile(".*Chest tracker: (\\d+)/(\\d+).*");

    // true while we're inside a "PAID CHEST REWARDS" ... blank-line block
    private boolean cedclient$inRewardBlock = false;

    @Inject(method = "handleSystemChat", at = @At("HEAD"), cancellable = true)
    private void cedclient$filterRewardSpam(ClientboundSystemChatPacket packet, CallbackInfo ci) {
        String clean = packet.content().getString().replaceAll("§.", "").trim();

        // "[IQ] Chest tracker: 12/60"
        if (CHEST_TRACKER.matcher(clean).matches()) {
            ci.cancel();
            return;
        }

        // "RARE REWARD! Someone found a Fuming Potato Book in their Bedrock Chest!"
        Matcher rare = RARE_REWARD.matcher(clean);
        if (rare.matches()) {
            LootTracker.INSTANCE.recordRareReward(rare.group(1), rare.group(2), rare.group(3));
            ci.cancel();
            return;
        }

        // Start of a "PAID CHEST REWARDS" block
        if (HEADER.matcher(clean).matches()) {
            cedclient$inRewardBlock = true;
            LootTracker.INSTANCE.recordChestOpened();
            ci.cancel();
            return;
        }

        if (cedclient$inRewardBlock) {
            if (clean.isEmpty()) {
                cedclient$inRewardBlock = false; // blank line closes the block
                ci.cancel();
                return;
            }
            LootTracker.INSTANCE.recordDrop(clean);
            ci.cancel();
            return;
        }

        // Standalone blank line (spacer before a block starts) — see class-level note.
        if (clean.isEmpty()) {
            ci.cancel();
        }
    }
}